# Backend

Recomendación de tiempo: 30 minutos de planeación, 30 minutos de
definición y diseño de arquitectura, diagramas, etc, 3 horas de
implementación, 1 hora de Pruebas-ajustes y 1 hora entrega.

Conexión base de datos:

HOST=bdfndtx6zpql36z6galp-mysql.services.clever-cloud.com

DB=bdfndtx6zpql36z6galp

USER=uggiwkwtiuq5p0g1

PORT=3306

PASSWORD=cXjltt08tSfeb7lZajei

URI=mysql://uggiwkwtiuq5p0g1:cXjltt08tSfeb7lZajei@bdfndtx6zpql36z6galp-mysql.services.clever-cloud.com:3306/bdfndtx6zpql36z6galp
